/*
    The MIT License (MIT)

    Copyright (c) 2016 Indy

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    More information can be acquired at https://opensource.org/licenses/MIT
*/

CoDaM CoDCommands ( CoCo ) by Indy

*** Custom CoDExtended REQUIRED ***
* Modders can add or edit more commands in *.pk3/commands.gsc
* Partial Name Matching is much faster way to execute id-required commands

Instructions: 
1. Install Custom CodExtended -> Provided with download in CoDExtended/codextended.so
        Instructions: https://github.com/iindy/CoDExtended#usage
1. Put __CoDaM_CoDCommands.pk3 in main
2. Open Codam\modlist.gsc and register the mod:
	[[ register ]]( "CoCo - CodCommands - Indy", codam\coco::main);
3. Add exec CoCo.cfg in "dedicated.cfg" and CHANGE THE PASSWORDS!
4. Run server- distribute appropriate passwords to group members
5. Groups can now login with !login [groupPassword] and do !help for full list of commands

TODO: 
- Better alias system
- More commands on the way

All questions and bugs should be directed to the forum thread
					OR
Contact me on Steam: http://steamcommunity.com/id/indyanz/